<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;         //nuevo componente
use Symfony\Component\Routing\Annotation\Route;

class ParametrosController extends AbstractController
{
    /**
     * @Route("/parametros", name="app_parametros")
     */
    public function index(): Response
    {
        return $this->render('parametros/index.html.twig', [
            'controller_name' => 'ParametrosController',
        ]);
    }
    
    /**
     * @Route("/valores", name="valoresFuncion" ,methods="POST")
     */
    public function valoresFuncion(Request $request): Response     //nuevo método y su ruta
    {
        
        return $this->render('parametros/muestraValor.html.twig', [ "valorDeLaVariable" => strtoupper($request->request->get("variable")) ]);
    }
}