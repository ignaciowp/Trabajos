<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Validator\Constraints\DateTime;

class PersonaController extends AbstractController
{
    #[Route('/persona', name: 'app_persona')]
    public function index(): Response
    {
        return $this->render('persona/index.html.twig', [
            'controller_name' => 'PersonaController',
        ]);
    }
    #[Route("/datos", name:"valores", methods:"POST")]
    public function valores(Request $request): Response
    {
        return $this->render('persona/vista.html.twig', [ "Nombre" => ucfirst(strtolower($request->request->get("nombre"))),
        "Apellido" => ucfirst(strtolower($request->request->get("apellido"))), 
        "Dni"=>($request->request->get("dni")),
        "Domicilio" =>($request->request->get("domicilio")), 
        "Edad" => $this->edad($request->request->get ("edad"))]);
    }
    public function edad($edad){
        $edadObjeto = new \DateTime(date($edad));   
        $hoy = new \DateTime();
        $calculoEdad= $hoy->diff($edadObjeto);
        return $calculoEdad->y;
    }
}