<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class SuerteController extends AbstractController
{
    #[Route('/suerte', name: 'app_suerte')]
    public function index(): Response
    {
        $numero_aleatorio = random_int(0, 100);                //generamos un numero aleatorio
        return $this->render('suerte/index.html.twig', [
            'controller_name' => 'SuerteController','numero_aleatorio' => $numero_aleatorio,    
                                                     //agregamos la variable para ser pasada a la Vista
        ]);
    }
}
